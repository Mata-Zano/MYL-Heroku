function recuperar(){
    window.location.href="recuperar"
}
function administrador(){
    
    window.location.href = "http://127.0.0.1:8000/MYL/administrador/";
     }
